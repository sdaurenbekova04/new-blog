import React from 'react';

const ArticleNotFound = ({title, description, image_url, price}) => {
  return (
    <div>
        <h1 className='article-title'>Статья не найдена</h1>
    </div>
  );
};

export default ArticleNotFound;
