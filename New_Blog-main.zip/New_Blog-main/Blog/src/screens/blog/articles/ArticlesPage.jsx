import React from 'react';
import ArticlesContent from './Layout';
// import NavBar from '../../../components/navBar/NavBar';


class ArticlesPage extends React.Component {
  render() {
    return <>
      {/* <NavBar /> */}
      <ArticlesContent />
    </>
  }
}
export default ArticlesPage;
